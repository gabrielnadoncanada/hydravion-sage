
<div id="dynamic-post"></div>

<div id="current-post">
    <x-package></x-package>
</div>
