module.exports = {
    plugins: {
        'tailwindcss': {},
        "autoprefixer": {},
        'postcss-nested': {}
    }
}
