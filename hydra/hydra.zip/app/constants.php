<?php

namespace App;

define('RESOURCE_URL', get_template_directory_uri() . '/resources');
